<?php
/*
 * Código de exemplo da utilização de PDO como persistencia
 * Classe Pessoa
 * @author Wesley R. Bezerra <wesley.bezerra@ifc.edu.br>
 * @version 0.2
 *
 */
class Pessoa
{
    public $id;
    public $nome;
    public $idade;
    public $peso;
    public $altura;
    public $nome_pai;
    public $nacionalidade;
    public $email;
    public $telefone;

    public function __construct()
    {
    }
}
?>
