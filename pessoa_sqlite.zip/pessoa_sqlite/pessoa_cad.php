<?php 
/*
* Código de exemplo da utilização de PDO como persistencia
* Página reponsável pelo formulário de cadastro da entidade Pessoa
* @author Wesley R. Bezerra <wesley.bezerra@ifc.edu.br>
* @version 0.1
*
*/
?>
<!DOCTYPE html>
<html lang="pt-BR">
<?php include 'cabecalho.php'; ?>
<?php
include "pessoa_acao.php";
$id = isset($_GET['id']) ? $_GET['id'] : 0;
$dados = array();
if ($id != 0)
    $dados = carregar($id);
?>

<body>
    <header class="container">
        <?php include 'menu.php'; ?>
    </header>
    <main class="container">

        <form action="pessoa_acao.php" method="post">
            <fieldset>
                <legend>Cadastro de Pessoas</legend>

                <label for="id">Id</label>
                <input type="text" name="id" id="id" value="<?= $id ?>" readonly><br>

                <label for="nome">Nome</label>
                <input type="text" size="40" name="nome" id="nome" value="<?= $id != 0 ? htmlspecialchars($dados['nome'] ?? '') : '' ?>" required><br>

                <label for="peso">Peso</label>
                <input type="number" step="0.01" name="peso" id="peso" value="<?= $id != 0 ? htmlspecialchars($dados['peso'] ?? '') : '' ?>"><br>

                <label for="altura">Altura</label>
                <input type="text" name="altura" id="altura" value="<?= $id != 0 ? htmlspecialchars($dados['altura'] ?? '') : '' ?>"><br>

                <label for="nome_pai">Nome do Pai</label>
                <input type="text" name="nome_pai" id="nome_pai" value="<?= $id != 0 ? htmlspecialchars($dados['nome_pai'] ?? '') : '' ?>"><br>

                <label for="nacionalidade">Nacionalidade</label>
                <input type="text" name="nacionalidade" id="nacionalidade" value="<?= $id != 0 ? htmlspecialchars($dados['nacionalidade'] ?? '') : '' ?>"><br>

                <label for="email">E-mail</label>
                <input type="email" name="email" id="email" value="<?= $id != 0 ? htmlspecialchars($dados['email'] ?? '') : '' ?>"><br>

                <label for="telefone">Telefone</label>
                <input type="text" name="telefone" id="telefone" value="<?= $id != 0 ? htmlspecialchars($dados['telefone'] ?? '') : '' ?>"><br>

                <input class="primary" type="submit" name="acao" id="acao" value="<?php if ($id == 0)
                    echo "Salvar";
                else
                    echo "Alterar";
                ?>">
                <input type="reset" value="Cancelar" />

            </fieldset>
        </form>
    </main>
    <footer class="container"></footer>
</body>

</html>