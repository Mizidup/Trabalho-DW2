<?php
/*
 * Código de exemplo da utilização de PDO como persistencia
 * Implementação PDO/SQLite da persistencia de Boleto
 * @version 0.1
 *
 */
include_once __DIR__ . "/BoletoDAO.php";
class PDOBoletoDAO extends BoletoDAO
{
    private static $instance = NULL;
    private $conn = NULL;

    function __construct()
    {
        $this->connect();
    }

    public static function getInstance()
    {
        if (self::$instance == NULL)
            self::$instance = new PDOBoletoDAO();
        return self::$instance;
    }

    /*
     * Método faz a conexao com o recurso usado
     * @return void
     */
    function connect()
    {
        $this->conn = new PDO('sqlite:' . __DIR__ . '/pessoas.db');
        $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    /* campos de data/valor vazios no formulário são gravados como NULL */
    private function nulo($valor)
    {
        return ($valor === "" || $valor === NULL) ? NULL : $valor;
    }

    private function parametros($objeto)
    {
        return array(
            ':data_vencimento' => $this->nulo($objeto->data_vencimento),
            ':data_emissao' => $this->nulo($objeto->data_emissao),
            ':data_pagamento' => $this->nulo($objeto->data_pagamento),
            ':valor' => $this->nulo($objeto->valor),
            ':desconto' => $this->nulo($objeto->desconto),
            ':juros' => $this->nulo($objeto->juros),
            ':multa' => $this->nulo($objeto->multa),
            ':mora' => $this->nulo($objeto->mora),
            ':valor_pago' => $this->nulo($objeto->valor_pago)
        );
    }

    /*
     * Método que insere dados no sistema de persistencia
     * @param $objeto Boleto objeto que será inserido
     * @return void
     */
    function inserir($objeto)
    {
        try {
            $stmt = $this->conn->prepare('INSERT INTO boleto
                (data_vencimento, data_emissao, data_pagamento, valor, desconto, juros, multa, mora, valor_pago)
                VALUES (:data_vencimento, :data_emissao, :data_pagamento, :valor, :desconto, :juros, :multa, :mora, :valor_pago)');
            $stmt->execute($this->parametros($objeto));
        } catch (PDOException $e) {
            error_log('Error: ' . $e->getMessage());
        }
    }

    /*
     * Método que altera dados no sistema de persistencia
     * @param $objeto Boleto objeto que será alterado
     * @return void
     */
    function alterar($objeto)
    {
        try {
            $stmt = $this->conn->prepare('UPDATE boleto SET
                data_vencimento=:data_vencimento, data_emissao=:data_emissao, data_pagamento=:data_pagamento,
                valor=:valor, desconto=:desconto, juros=:juros, multa=:multa, mora=:mora, valor_pago=:valor_pago
                WHERE id=:id');
            $params = $this->parametros($objeto);
            $params[':id'] = $objeto->id;
            $stmt->execute($params);
        } catch (PDOException $e) {
            error_log('Error: ' . $e->getMessage());
        }
    }

    /*
     * Método que exclui dados no sistema de persistencia
     * @param $id int identificador do registro
     * @return void
     */
    function excluir($id)
    {
        try {
            $stmt = $this->conn->prepare('DELETE FROM boleto WHERE id=:id');
            $stmt->execute(array(':id' => $id));
        } catch (PDOException $e) {
            error_log('Error: ' . $e->getMessage());
        }
    }

    /*
     * Método que lista dados no sistema de persistencia
     * @return array array de dados
     */
    function listar()
    {
        $dados = array();
        try {
            $result = $this->conn->query("SELECT * FROM boleto ORDER BY id");
            $dados = $result->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log('Error: ' . $e->getMessage());
        }
        return $dados;
    }

    /*
     * Método que obtem dados no sistema de persistencia
     * @param $id int identificador do registro
     * @return array objeto em array
     */
    function obter($id)
    {
        $boleto = array();
        try {
            $stmt = $this->conn->prepare("SELECT * FROM boleto WHERE id=:id");
            $stmt->execute(array(':id' => $id));
            $linha = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($linha)
                $boleto = $linha;
        } catch (PDOException $e) {
            error_log('Error: ' . $e->getMessage());
        }
        return $boleto;
    }
}
?>
