<?php
require_once "boleto.php";
require_once "persistencia/PDOBoletoDAO.php";
define("DESTINO_BOLETO", "boleto_list.php");

$acao = "";
switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        $acao = isset($_GET['acao']) ? $_GET['acao'] : "";
        break;
    case 'POST':
        $acao = isset($_POST['acao']) ? $_POST['acao'] : "";
        break;
}

switch ($acao) {
    case 'Salvar':
        salvar();
        break;
    case 'Alterar':
        alterar();
        break;
    case 'excluir':
        excluir();
        break;
}

function tela2array()
{
    $campos = array('id', 'data_vencimento', 'data_emissao', 'data_pagamento', 'valor',
        'desconto', 'juros', 'multa', 'mora', 'valor_pago');
    $novo = array();
    foreach ($campos as $c)
        $novo[$c] = isset($_POST[$c]) ? trim($_POST[$c]) : "";
    return $novo;
}

function array2objeto($array_dados)
{
    $elemento = new Boleto();
    $elemento->id = $array_dados['id'];
    $elemento->data_vencimento = $array_dados['data_vencimento'];
    $elemento->data_emissao = $array_dados['data_emissao'];
    $elemento->data_pagamento = $array_dados['data_pagamento'];
    $elemento->valor = $array_dados['valor'];
    $elemento->desconto = $array_dados['desconto'];
    $elemento->juros = $array_dados['juros'];
    $elemento->multa = $array_dados['multa'];
    $elemento->mora = $array_dados['mora'];
    $elemento->valor_pago = $array_dados['valor_pago'];
    return $elemento;
}

function objeto2array($elemento)
{
    return get_object_vars($elemento);
}

function carregar($id)
{
    $dao = PDOBoletoDAO::getInstance();
    return $dao->obter($id);
}

function alterar()
{
    $dao = PDOBoletoDAO::getInstance();
    $dao->alterar(array2objeto(tela2array()));
    header("location:" . DESTINO_BOLETO);
}

function excluir()
{
    $id = isset($_GET['id']) ? $_GET['id'] : "";
    $dao = PDOBoletoDAO::getInstance();
    $dao->excluir($id);
    header("location:" . DESTINO_BOLETO);
}


function salvar()
{
    $dao = PDOBoletoDAO::getInstance();
    $dao->inserir(array2objeto(tela2array()));
    header("location:" . DESTINO_BOLETO);
}
?>
