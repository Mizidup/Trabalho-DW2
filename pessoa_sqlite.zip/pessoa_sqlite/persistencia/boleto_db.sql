CREATE TABLE boleto (
    id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    data_vencimento DATE,
    data_emissao DATE,
    data_pagamento DATE,
    valor NUMERIC(10,2),
    desconto NUMERIC(10,2),
    juros NUMERIC(10,2),
    multa NUMERIC(10,2),
    mora NUMERIC(10,2),
    valor_pago NUMERIC(10,2)
);
