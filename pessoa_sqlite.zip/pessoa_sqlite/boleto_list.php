<?php

?>
<!DOCTYPE html>
<html lang="pt-BR">
<?php include 'cabecalho.php'; ?>
<?php require_once 'boleto_acao.php'; ?>
<?php
function fmt_data($d)
{
    return ($d === NULL || $d === "") ? "-" : date("d/m/Y", strtotime($d));
}
function fmt_valor($v)
{
    return ($v === NULL || $v === "") ? "-" : number_format((float) $v, 2, ',', '.');
}
?>

<body>
    <main class="container">
        <?php include 'menu.php'; ?>
        <?php
        $dao = PDOBoletoDAO::getInstance();
        $dados = $dao->listar();
        if (($dados == NULL) || (count($dados) == 0)) {
            echo "<div><span class='warning'>sem dados a serem exibidos</span></div>";
        }
        ?>
        <table role="grid">
            <tr>
                <th>Id</th>
                <th>Vencimento</th>
                <th>Emissão</th>
                <th>Pagamento</th>
                <th>Valor</th>
                <th>Desconto</th>
                <th>Juros</th>
                <th>Multa</th>
                <th>Mora</th>
                <th>Valor pago</th>
                <th>Alterar</th>
                <th>Excluir</th>
            </tr>
            <?php
            foreach ($dados as $key)
                echo "<tr><td>{$key['id']}</td>
                  <td>" . fmt_data($key['data_vencimento']) . "</td>
                  <td>" . fmt_data($key['data_emissao']) . "</td>
                  <td>" . fmt_data($key['data_pagamento']) . "</td>
                  <td>" . fmt_valor($key['valor']) . "</td>
                  <td>" . fmt_valor($key['desconto']) . "</td>
                  <td>" . fmt_valor($key['juros']) . "</td>
                  <td>" . fmt_valor($key['multa']) . "</td>
                  <td>" . fmt_valor($key['mora']) . "</td>
                  <td>" . fmt_valor($key['valor_pago']) . "</td>
                  <td align='center'><a role='button' href='boleto_cad.php?id=" . $key['id'] . "'>A</a></td>
                  <td align='center'><a role='button' href=javascript:excluirRegistro('boleto_acao.php?acao=excluir&id=" . $key['id'] . "');>E</a></td>
              </tr>";
            ?>
        </table>
    </main>
    <script>
        function excluirRegistro(url) {
            if (confirm("Confirmar Exclusão?"))
                location.href = url;
        }
    </script>
</body>

</html>
