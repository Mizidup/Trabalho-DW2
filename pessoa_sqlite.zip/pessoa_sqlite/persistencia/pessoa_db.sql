CREATE TABLE pessoa (
    id INTEGER NOT NULL PRIMARY KEY,
    nome VARCHAR(255),
    idade INTEGER,
    peso FLOAT(8,2),
    altura FLOAT(8,2),
    nome_pai TEXT,
    nacionalidade TEXT,
    email TEXT,
    telefone TEXT
);

-- Migração da etapa 2 (aplicada sobre o pessoas.db existente):
-- ALTER TABLE pessoa ADD COLUMN email TEXT;
-- ALTER TABLE pessoa ADD COLUMN telefone TEXT;
